package modelo.tareas;

import modelo.extra.Receta;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;

// manejo de las colecciones
public class ManejoTarea {

}